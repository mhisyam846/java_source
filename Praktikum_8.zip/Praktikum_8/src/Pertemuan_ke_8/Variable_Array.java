package Pertemuan_ke_8;
import javax.swing.*;
public class Variable_Array {
	public static void main(String[] args) {
		// No 3 A -- jumlah element
		int iDx = Integer.parseInt(JOptionPane.showInputDialog("Masukan Jumlah Element"));
		int data[] = new int[iDx];
		
		int max = 0, min = 0;
		int pos_max = 0, pos_min = 0;
		
		double jml = 0;
		// No 3 B -- input nilai pada element
		for(int a = 0; a < data.length; a++) {
			data[a] = Integer.parseInt(JOptionPane.showInputDialog("Masukan Element Index Ke " + a));
			// No 3 C -- Nilai Terbesar Terkecil
			if(data[a] > max) { 
				max = data[a];
				pos_max = a;
			}
			if(a==0) min = data[a];
			if(data[a] < min) { min = data[a]; pos_min = a; }
			// No 3 D -- Jumlah Nilai Pada Array
			jml += data[a];
		}
		// Soal No 3 C -- Tampilan Nilai Min Max
		System.out.println("Nilai Max : " + max + " Indeks Ke " + pos_max);
		System.out.println("Nilai Min : " + min + " Indeks Ke " + pos_min);
		// Soal No 3 D -- Tampilkan Jumlah Nilai
		System.out.println("Jumlah Nilai Pada Array : " + jml);
		double rata = jml / data.length;
		System.out.println("Nilai Rata Rata " + rata);
		// Soal No 3 E --  Penjumlahan Nilai pada indeks ganjil genap
		int nilai_ganjil = 0, nilai_genap = 0;
		for(int a = 0; a < data.length; a++) {
			if(a % 2 == 0) nilai_genap += data[a]; // jika data bernilai genap
			else nilai_ganjil += data[a]; // jika data bernilai ganjil
		}
		System.out.println("Jumlah Nilai Indeks Ganjil " + nilai_ganjil);
		System.out.println("Jumlah Nilai Indeks Genap " + nilai_genap);
		// Soal No 3 F -- Cek Nilai
		if(nilai_ganjil % 2 == 1) System.out.println("Nilai Indeks Ganjil adalah Ganjil");
		else System.out.println("Nilai Indeks Ganjil adalah Genap");
			// -- 
		if(nilai_genap % 2 == 1) System.out.println("Nilai Indeks Genap adalah Ganjil");
		else System.out.println("Nilai Indeks Genap adalah Genap");
		// Soal No 3 G -- Pengurutan Element Array
		int ar_chg = 0;
		for(int a = 0; a < data.length; a++) {
			for(int b = 0; b < data.length - 1; b++) {
				if(data[b + 1] > data[b]) {
					ar_chg = data[b + 1];
					data[b + 1] = data[b];
					data[b] = ar_chg;
				}
			}
		}
		for(int a = 0; a < data.length; a++) {
			System.out.println("Index Ke " + a + " Adalah " + data[a]);
		}
	}
}
