package Pertemuan_ke_8;
import javax.swing.*;
public class NewClass2 {
	public static void main(String[] args) {
		int data[] = new int[10];
		int max = 0, min = 0;
		int pos_max = 0, pos_min = 0;
		double rata = 0;
		for(int a = 0; a < data.length; a++) {
			data[a] = Integer.parseInt(JOptionPane.showInputDialog("Masukan Element Index Ke " + a));
			System.out.println("Index Ke " + a + " Adalah " + data[a]);
			if(data[a] > max) {
				max = data[a];
				pos_max = a;
			}
			
			if(a==0) min = data[a];
			if(data[a] < min) {
				min = data[a];
				pos_min = a;
			}
			
			rata += data[a];
		}
		// Soal No 2 A
		System.out.println("Nilai Max : " + max + " Indeks Ke " + pos_max);
		System.out.println("Nilai Min : " + min + " Indeks Ke " + pos_min);
		// Soal No 2 B
		rata /= data.length;
		System.out.println("Nilai Rata-Rata : " + rata);
		// Soal No 2 C -- Pencarian Nilai
		int sd = Integer.parseInt(JOptionPane.showInputDialog("Masukan Nilai Yang Ingin Dicari"));
		int si = 0;
		for(int a = 0; a < data.length; a++) {
			if(data[a] == sd) si = a;
		}
		System.out.println("Nilai " + sd + " di Indeks Ke " + si);
		data[si] = Integer.parseInt(JOptionPane.showInputDialog("Ganti Nilai pada Indeks Ke " + si));
		// Element Baru
		for(int a = 0; a < data.length; a++) {
			System.out.println("Index Ke " + a + " Adalah " + data[a]);
		}
	}
}
